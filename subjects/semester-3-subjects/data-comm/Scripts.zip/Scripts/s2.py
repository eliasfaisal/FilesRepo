
import matplotlib as mpl
import soundfile
import numpy as np                                                                     #code 1
import matplotlib.pyplot as pit    
from scipy.io import wavfile
from IPython.display import display, Audio 
from scipy.io import wavfile
sample_rate_sond_wave = 96100
frequnacy_sin_sound_wave = 7500        
lenght = 15.0     
t = np.arange(0, lenght, 1.0 / sample_rate_sond_wave)
signal = np.sin(np.pi * 2 *frequnacy_sin_sound_wave* t)
signal *= 32767
signal = np.int16(signal)
wavfile.write("sine2.wav", sample_rate_sond_wave, signal)
#



#



#




#