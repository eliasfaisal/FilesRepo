import matplotlib as mpl
import soundfile
import numpy as np                                                                     
import matplotlib.pyplot as pit    
from scipy.io import wavfile
from IPython.display import display, Audio 
from scipy.io import wavfile
import wave                                                                     
import matplotlib.pyplot as wavfile   
from IPython.display import display, Audio 

sample_rate_sond_wave = 35100
frequnacy_sin_sound_wave = 750        
lenght = 15.0     
t = np.arange(0, lenght, 1.0 / sample_rate_sond_wave)
signal = np.sin(np.pi * 2 *frequnacy_sin_sound_wave* t)
signal *= 32767
signal = np.int16(signal)
wavfile.write("sine1.wav", sample_rate_sond_wave, signal)

sample_rate_sond_wave = 96100
frequnacy_sin_sound_wave = 7500        
lenght = 15.0     
t = np.arange(0, lenght, 1.0 / sample_rate_sond_wave)
signal = np.sin(np.pi * 2 *frequnacy_sin_sound_wave* t)
signal *= 32767
signal = np.int16(signal)
wavfile.write("sine2.wav", sample_rate_sond_wave, signal)


file_names =["./sine1.wav", "./sine2.wav"]
wavs = [wave.open(fn) for fn in file_names]
frames = [w.readframes(w.getnframes()) for w in wavs]


samples = [np.frombuffer(f, dtype='<i2') for f in frames]
samples = [samp.astype(np.float64) for samp in samples]


n = min(map(len, samples))
mix = samples[0][:n] + samples[1][:n]
# Save the result
dual_wave = wave.open("./dualwave.wav", 'w')
dual_wave.setparams(wavs[0].getparams())


dual_wave.writeframes(mix.astype('<i2').tobytes())
dual_wave.close()