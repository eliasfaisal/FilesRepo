import matplotlib as mpl
import wave
import soundfile
import numpy as np                                                                     #code 1
import matplotlib.pyplot as wavfile   
from scipy.io import wavfile
from IPython.display import display, Audio 


file_names =["./sine1.wav", "./sine2.wav"]
wavs = [wave.open(fn) for fn in file_names]
frames = [w.readframes(w.getnframes()) for w in wavs]


samples = [np.frombuffer(f, dtype='<i2') for f in frames]
samples = [samp.astype(np.float64) for samp in samples]


n = min(map(len, samples))
mix = samples[0][:n] + samples[1][:n]
# Save the result
dual_wave = wave.open("./dualwave.wav", 'w')
dual_wave.setparams(wavs[0].getparams())


dual_wave.writeframes(mix.astype('<i2').tobytes())
dual_wave.close()